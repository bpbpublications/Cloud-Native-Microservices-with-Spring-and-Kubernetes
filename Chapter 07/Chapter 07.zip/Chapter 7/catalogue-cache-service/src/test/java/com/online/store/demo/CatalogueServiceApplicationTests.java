package com.online.store.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
