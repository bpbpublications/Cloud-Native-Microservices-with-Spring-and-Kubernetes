package com.online.store.demo.springgatewaydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGatewayDemoApplicationTests {

	@Test
	void contextLoads() {
	}
}