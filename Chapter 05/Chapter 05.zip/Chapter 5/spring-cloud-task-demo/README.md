# spring-cloud-task-demo

A short lived microservice application using Spring Cloud Task on underlying Spring Boot library
