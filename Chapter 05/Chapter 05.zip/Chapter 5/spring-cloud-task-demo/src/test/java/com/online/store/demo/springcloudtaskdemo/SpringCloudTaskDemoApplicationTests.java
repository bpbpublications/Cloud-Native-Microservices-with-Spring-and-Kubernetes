package com.online.store.demo.springcloudtaskdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudTaskDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
